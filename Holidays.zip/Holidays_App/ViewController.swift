//
//  ViewController.swift
//  Holidays_App
//
//  Created by Oleksii Kolakovskyi on 10/30/19.
//  Copyright © 2019 Aleksey. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

